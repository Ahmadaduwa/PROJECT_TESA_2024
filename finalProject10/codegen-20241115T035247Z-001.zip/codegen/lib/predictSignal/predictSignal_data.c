/*
 * Sponsored License - for use in support of a program or activity
 * sponsored by MathWorks.  Not for government, commercial or other
 * non-sponsored organizational use.
 * File: predictSignal_data.c
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 15-Nov-2024 10:15:10
 */

/* Include Files */
#include "predictSignal_data.h"
#include "rt_nonfinite.h"

/* Variable Definitions */
omp_nest_lock_t predictSignal_nestLockGlobal;

bool isInitialized_predictSignal = false;

/*
 * File trailer for predictSignal_data.c
 *
 * [EOF]
 */
