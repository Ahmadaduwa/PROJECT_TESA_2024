/*
 * Sponsored License - for use in support of a program or activity
 * sponsored by MathWorks.  Not for government, commercial or other
 * non-sponsored organizational use.
 * File: _coder_predictSignal_info.h
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 15-Nov-2024 10:15:10
 */

#ifndef _CODER_PREDICTSIGNAL_INFO_H
#define _CODER_PREDICTSIGNAL_INFO_H

/* Include Files */
#include "mex.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for _coder_predictSignal_info.h
 *
 * [EOF]
 */
