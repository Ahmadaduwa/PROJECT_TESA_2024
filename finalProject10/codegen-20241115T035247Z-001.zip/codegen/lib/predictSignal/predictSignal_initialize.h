/*
 * Sponsored License - for use in support of a program or activity
 * sponsored by MathWorks.  Not for government, commercial or other
 * non-sponsored organizational use.
 * File: predictSignal_initialize.h
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 15-Nov-2024 10:15:10
 */

#ifndef PREDICTSIGNAL_INITIALIZE_H
#define PREDICTSIGNAL_INITIALIZE_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void predictSignal_initialize(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for predictSignal_initialize.h
 *
 * [EOF]
 */
