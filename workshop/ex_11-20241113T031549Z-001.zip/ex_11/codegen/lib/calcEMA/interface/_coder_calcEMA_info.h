/*
 * Sponsored License - for use in support of a program or activity
 * sponsored by MathWorks.  Not for government, commercial or other
 * non-sponsored organizational use.
 * File: _coder_calcEMA_info.h
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 13-Nov-2024 10:05:21
 */

#ifndef _CODER_CALCEMA_INFO_H
#define _CODER_CALCEMA_INFO_H

/* Include Files */
#include "mex.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for _coder_calcEMA_info.h
 *
 * [EOF]
 */
