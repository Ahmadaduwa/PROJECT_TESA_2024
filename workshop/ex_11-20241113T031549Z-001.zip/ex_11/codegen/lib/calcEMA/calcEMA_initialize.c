/*
 * Sponsored License - for use in support of a program or activity
 * sponsored by MathWorks.  Not for government, commercial or other
 * non-sponsored organizational use.
 * File: calcEMA_initialize.c
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 13-Nov-2024 10:05:21
 */

/* Include Files */
#include "calcEMA_initialize.h"

/* Function Definitions */
/*
 * Arguments    : void
 * Return Type  : void
 */
void calcEMA_initialize(void)
{
}

/*
 * File trailer for calcEMA_initialize.c
 *
 * [EOF]
 */
