data = rand(1, 100);
N = uint32(8);
ema_result = calcEMA(data, N);
