/*
 * Sponsored License - for use in support of a program or activity
 * sponsored by MathWorks.  Not for government, commercial or other
 * non-sponsored organizational use.
 * File: calcEMA_terminate.h
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 13-Nov-2024 10:05:21
 */

#ifndef CALCEMA_TERMINATE_H
#define CALCEMA_TERMINATE_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void calcEMA_terminate(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for calcEMA_terminate.h
 *
 * [EOF]
 */
