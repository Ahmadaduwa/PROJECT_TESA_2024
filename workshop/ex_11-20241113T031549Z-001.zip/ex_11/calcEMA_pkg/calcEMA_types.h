/*
 * Sponsored License - for use in support of a program or activity
 * sponsored by MathWorks.  Not for government, commercial or other
 * non-sponsored organizational use.
 * File: calcEMA_types.h
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 13-Nov-2024 10:05:21
 */

#ifndef CALCEMA_TYPES_H
#define CALCEMA_TYPES_H

/* Include Files */
#include "rtwtypes.h"

#endif
/*
 * File trailer for calcEMA_types.h
 *
 * [EOF]
 */
