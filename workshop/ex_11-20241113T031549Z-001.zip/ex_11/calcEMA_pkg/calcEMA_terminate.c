/*
 * Sponsored License - for use in support of a program or activity
 * sponsored by MathWorks.  Not for government, commercial or other
 * non-sponsored organizational use.
 * File: calcEMA_terminate.c
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 13-Nov-2024 10:05:21
 */

/* Include Files */
#include "calcEMA_terminate.h"

/* Function Definitions */
/*
 * Arguments    : void
 * Return Type  : void
 */
void calcEMA_terminate(void)
{
}

/*
 * File trailer for calcEMA_terminate.c
 *
 * [EOF]
 */
