/*
 * Sponsored License - for use in support of a program or activity
 * sponsored by MathWorks.  Not for government, commercial or other
 * non-sponsored organizational use.
 * File: sound_freq_terminate.c
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 13-Nov-2024 11:48:35
 */

/* Include Files */
#include "sound_freq_terminate.h"
#include "rt_nonfinite.h"

/* Function Definitions */
/*
 * Arguments    : void
 * Return Type  : void
 */
void sound_freq_terminate(void)
{
}

/*
 * File trailer for sound_freq_terminate.c
 *
 * [EOF]
 */
