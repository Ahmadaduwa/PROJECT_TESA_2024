in = rand(1,4096) ;
sp = sound_freq(in);