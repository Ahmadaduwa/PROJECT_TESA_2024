/*
 * Sponsored License - for use in support of a program or activity
 * sponsored by MathWorks.  Not for government, commercial or other
 * non-sponsored organizational use.
 * File: abs.h
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 13-Nov-2024 11:48:35
 */

#ifndef ABS_H
#define ABS_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void b_abs(const creal_T x[4096], double y[4096]);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for abs.h
 *
 * [EOF]
 */
