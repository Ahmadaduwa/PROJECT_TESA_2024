/*
 * Sponsored License - for use in support of a program or activity
 * sponsored by MathWorks.  Not for government, commercial or other
 * non-sponsored organizational use.
 * File: sound_freq_initialize.h
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 13-Nov-2024 11:48:35
 */

#ifndef SOUND_FREQ_INITIALIZE_H
#define SOUND_FREQ_INITIALIZE_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void sound_freq_initialize(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for sound_freq_initialize.h
 *
 * [EOF]
 */
