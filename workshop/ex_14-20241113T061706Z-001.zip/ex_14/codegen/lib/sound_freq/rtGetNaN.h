/*
 * Sponsored License - for use in support of a program or activity
 * sponsored by MathWorks.  Not for government, commercial or other
 * non-sponsored organizational use.
 * File: rtGetNaN.h
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 13-Nov-2024 11:48:35
 */

#ifndef RTGETNAN_H
#define RTGETNAN_H

/* Include Files */
#include "rtwtypes.h"

#ifdef __cplusplus
extern "C" {
#endif

extern real_T rtGetNaN(void);
extern real32_T rtGetNaNF(void);

#ifdef __cplusplus
}
#endif
#endif
/*
 * File trailer for rtGetNaN.h
 *
 * [EOF]
 */
