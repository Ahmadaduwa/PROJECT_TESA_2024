#ifndef PORTABLE_WORDSIZES
#ifdef __MW_TARGET_USE_HARDWARE_RESOURCES_H__
#ifndef __MW_TARGET_HARDWARE_RESOURCES_H__
#define __MW_TARGET_HARDWARE_RESOURCES_H__

#include "MW_Pyserver_control.h"
#include "MW_raspi_init.h"


#endif /* __MW_TARGET_HARDWARE_RESOURCES_H__ */

#endif

#endif
